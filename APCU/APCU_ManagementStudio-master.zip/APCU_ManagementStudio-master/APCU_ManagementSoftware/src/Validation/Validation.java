
package Validation;

import DB.DBconnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Validation {
    Connection connection = null;
    PreparedStatement pst = null;
    ResultSet rs =null;
    
    public Validation(){
        connection = DBconnect.connect();
    }
    
    
    public boolean emailValidation(String email){
        boolean result;
        char emailArray[] = email.toCharArray();
        int letter = 0, whiteSpace=0, atSign=0, test;
        
        for(char ch:emailArray){
             test = (Character.isWhitespace(ch)? whiteSpace++: (ch=='@')?atSign++ : letter++);
        }
        
        
        result = (whiteSpace==0 && atSign==1)? true: false;
        return result;
    }
    
    
    public boolean telephoneValidation(String telephone, int input){
        boolean result;
        char telephoneArray[] = telephone.toCharArray();
        int number = 0, letter=0, test=0;
        
        for(char ch:telephoneArray){
            test = (Character.isDigit(ch))? number++ : letter++ ;
        }
        
        if(input==1){
            result = (number == 10)? true : false ;   
        }else{
            result = (number == 0 && letter == 0)? true : false ;
        }
        
        return result; 
    }
    
    
    public boolean accountNoValidation(String pAccountNo){
        boolean result;
        char accountNoArray[] = pAccountNo.toCharArray();
        int number = 0, letter=0, test=0;
        
        for(char ch:accountNoArray){
            test = (Character.isDigit(ch))? number++ : letter++ ;
        }
        
        result = (accountNoArray.length == number)? true : false ;
        
        return result; 
    }
        
}
